# Belmont - Ad Montem Sapientiae

Welcome to the Belmont project! This project aims to blend the curiosity and revolutionary spirit of the Renaissance with the cutting-edge technologies of today. Our goal is to foster an environment where creativity and technology intertwine, leading to groundbreaking innovations that can reshape our world.

## Table of Contents

- [About](#about)
- [Events](#events)
- [Leaders](#leaders)
- [Members](#members)

## About

Belmont is a group of individuals dedicated to exploring, gaining, and imparting knowledge to build things and make a change in how the world operates. We strive to become wise and knowledgeable, questioning everything and finding answers to our inquiries.

## Events

We regularly host events to engage our members and the community. Some of our latest events include:

- **PC Building Stand-off**: A competition where teams assemble computers using provided components.
- **Dev Tools Workshop**: An informative workshop on Development Tools.

## Leaders

Our leaders are dedicated individuals who guide and inspire our members:

- **CB Sriharshini**: Captain Bash, Crew 4
- **CB Haleel Rahman**: Captain Bash, Crew 3

## Members

Our members are passionate individuals honing their skills in various fields:

- **Jeshwin Antony Benedictus**: Business Analytics
- **Prim Sajun**: Web Development
- **Michal Nithesh**: Software Development
- **Maxwell Rubert**: Data Science
- **Amrutha**: Web Development
- **Jerlin Shabi**: Web Development